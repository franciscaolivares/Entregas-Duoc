package model;

import interfaces.Cancelable;
import interfaces.Despachable;
import interfaces.Rastreable;

public class PedidoComida extends Pedido implements Despachable, Cancelable, Rastreable {
    public PedidoComida() {
    }

    public PedidoComida(int idPedido, String direccionEntrega, double distanciaKm) {
        super(idPedido, direccionEntrega, "Comida", distanciaKm);
    }

    @Override
    public int calcularTiempoEntrega() {

        return (int) Math.round(15 + (2 * getDistanciaKm()));
    }

    @Override
    public void asignarRepartidor() {
        System.out.println("Asignando repartidor para pedido de comida...");
        System.out.println("Verificando que cuente con mochila térmica... OK");
    }

    @Override
    public void asignarRepartidor(String nombreRepartidor) {
        System.out.println("Mochila térmica de " + nombreRepartidor + " verificada.");
        System.out.println("Pedido de comida asignado a " + nombreRepartidor + ".");
    }
}
